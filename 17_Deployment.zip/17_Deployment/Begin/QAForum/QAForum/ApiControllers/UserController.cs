﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
//using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;
using QAForum.Data;

namespace QAForum.ApiControllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly SignInManager<ApplicationUser> signinManager;
        private readonly IConfiguration config;

        public UserController(UserManager<ApplicationUser> userManager,
                        SignInManager<ApplicationUser> signinManager,
                        IConfiguration config)
        {
            this.userManager = userManager;
            this.signinManager = signinManager;
            this.config = config;
        }

        [HttpPost("signin")]
        public async Task<IActionResult> SignInAsync([FromForm]string username, [FromForm]string password)
        {
            var user = await userManager.FindByNameAsync(username);
            var result = await signinManager.PasswordSignInAsync(user, password, false, false);

            if (result == Microsoft.AspNetCore.Identity.SignInResult.Success)
            {
                // Signing in successfully places a cookie in the response.
                // Remove the cookie from the response, since JWT will replace
                // the cookie
                Response.Cookies.Delete(".AspNetCore.Identity.Application");
                var token = await GenerateJwtToken(user);
                return Ok(token);
            }

            return Unauthorized();
        }

        private async Task<string> GenerateJwtToken(ApplicationUser user)
        {
            var claims = new List<Claim>
            {
                // Add some standard claims to the new token
                new Claim(JwtRegisteredClaimNames.Sub, user.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.NameIdentifier, user.Id),
                new Claim(ClaimTypes.Name, user.UserName)
            };
            // Copy all the user's claims from the Identity system's claims
            // list into the JWT token
            foreach (var claim in await userManager.GetClaimsAsync(user))
            {
                claims.Add(claim);
            }
            var jwtKey = Encoding.UTF8.GetBytes(config["JwtTokenSettings:JwtKey"]);
            var key = new SymmetricSecurityKey(jwtKey);
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            var expires = DateTime.Now.AddDays(int.Parse(config["JwtTokenSettings:JwtExpireDays"]));

            var token = new JwtSecurityToken(
                config["JwtTokenSettings:JwtIssuer"],
                config["JwtTokenSettings:JwtAudience"],
                claims,
                expires: expires,
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}