﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.AuthorizationRequirements
{
    public class DaysOfWeekHandler : AuthorizationHandler<DaysOfWeekRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, DaysOfWeekRequirement requirement)
        {
            int currentSystemDay = (int)DateTime.Now.DayOfWeek;

            // Convert the System.DayOfWeek (a data type that does
            // not support representing a group of days, only a single
            // day) to our own enum
            DaysOfWeek currentDay = (DaysOfWeek)Math.Pow(2, currentSystemDay);

            // See if today is one of the days that's allowed
            if ((requirement.DaysOfWeek & currentDay) == currentDay)
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }
    }
}
