﻿using Microsoft.AspNetCore.Authorization;
using QAForum.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.AuthorizationRequirements
{
    public class DaysOfWeekdAdminHandler : AuthorizationHandler<DaysOfWeekRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, DaysOfWeekRequirement requirement)
        {
            if (context.User.HasClaim(claim => claim.Type == Claims.ADMIN_CLAIM))
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }
    }
}
