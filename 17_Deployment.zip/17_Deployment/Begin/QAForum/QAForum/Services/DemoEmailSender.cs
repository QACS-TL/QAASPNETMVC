﻿using Microsoft.AspNetCore.Identity.UI.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.Services
{
    public class DemoEmailSender : IEmailSender
    {
        public async Task SendEmailAsync(string email, string subject, string htmlMessage)
        {
            var message = @$"<div><strong>To: </strong>{email}</div>
                            <div><strong>Subject: </strong>{subject}</div>
                            <hr />
                            {htmlMessage}";

            var filename = @$"C:\Users\Public\QAForumEmail{
                DateTime.Now.ToString("yyyyMMddHHmmss")}.html";
            using (var writer = new StreamWriter(filename))
            {
                await writer.WriteAsync(message);
            }
        }
    }
}
