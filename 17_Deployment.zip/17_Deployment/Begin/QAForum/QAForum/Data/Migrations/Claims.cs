﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.Data
{
    public static class Claims
    {
        public const string ADMIN_CLAIM = "Administrator";
    }
}
