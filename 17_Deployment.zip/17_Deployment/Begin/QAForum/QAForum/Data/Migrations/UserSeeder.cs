﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace QAForum.Data
{
    public class UserSeeder
    {
        private readonly UserManager<ApplicationUser> userManager;

        public UserSeeder(UserManager<ApplicationUser> userManager)
        {
            this.userManager = userManager;
        }

        public async Task SeedUsers()
        {
            const string email = "admin@qaforum.com";
            const string password = "Pa$$w0rd";

            var existingUser = await userManager.FindByNameAsync(email);
            if (existingUser != null)
            {
                // The user already exists
                return;
            }

            var user = new ApplicationUser
            {
                UserName = email,
                Email = email,
                EmailConfirmed = true
            };
            
            var result = await userManager.CreateAsync(user, password);
            if (result != IdentityResult.Success)
            {
                throw new ApplicationException("Failed to create admin user");
            }

            result = await userManager.AddClaimAsync(user, new Claim(Claims.ADMIN_CLAIM, ""));
            if (result != IdentityResult.Success)
            {
                throw new ApplicationException("Failed to add Administrator claim");
            }
        }
    }
}
