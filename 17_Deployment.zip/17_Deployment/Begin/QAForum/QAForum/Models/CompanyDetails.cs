﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.Models
{
    public class CompanyDetails
    {
        public string CompanyName { get; set; }
        public string Email { get; set; }
    }
}
