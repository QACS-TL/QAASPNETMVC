﻿using Microsoft.AspNetCore.Mvc;
using QAForum.Areas.Users.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.Areas.Users.ViewComponents
{
    public class RecentPostsViewComponent : ViewComponent
    {
        private readonly IStateRepository state;

        public RecentPostsViewComponent(IStateRepository state)
        {
            this.state = state;
        }

        public IViewComponentResult Invoke()
        {
            return View(state.GetRecentPosts());
        }
    }
}
