﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using QAForum.Areas.Users.ViewModels;
using QAForum.Data;
using QAForum.EF;
using QAForum.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.Areas.Users.ViewComponents
{
    public class PostListViewComponent : ViewComponent
    {
        private readonly ForumDbContext context;
        private readonly UserManager<ApplicationUser> userManager;

        public PostListViewComponent(ForumDbContext context, UserManager<ApplicationUser> userManager)
        {
            this.context = context;
            this.userManager = userManager;
        }

        public IViewComponentResult Invoke(int? threadId)
        {
            IQueryable<Post> posts = context.Posts;
            if (threadId.HasValue)
            {
                posts = posts.Where(p => p.ThreadId == threadId);
            }
            return View("~/Areas/Users/Views/Post/_PostList.cshtml",PostViewModel.FromPosts(posts, userManager));

        }
    }
}
