﻿using QAForum.Areas.Users.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.Areas.Users.Repositories
{
    public interface IStateRepository
    {
        public void SetRecentPosts(List<RecentPostViewModel> recentPosts);
        public List<RecentPostViewModel> GetRecentPosts();
    }
}
