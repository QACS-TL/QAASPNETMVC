﻿using Microsoft.AspNetCore.Http;
using QAForum.Areas.Users.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace QAForum.Areas.Users.Repositories
{
    public class StateRepository : IStateRepository
    {
        private const string RECENT_POSTS_KEY = "RECENT_POSTS";
        private readonly IHttpContextAccessor httpContextAccessor;

        public StateRepository(IHttpContextAccessor httpContextAccessor)
        {
            this.httpContextAccessor = httpContextAccessor;
        }

        public List<RecentPostViewModel> GetRecentPosts()
        {
            var json = httpContextAccessor.HttpContext.Session.GetString("RECENT_POSTS");
            if (json == null)
            {
                return new List<RecentPostViewModel>();
            }
            else
            {
                return JsonSerializer.Deserialize<List<RecentPostViewModel>>(json);
            }
        }

        public void SetRecentPosts(List<RecentPostViewModel> recentPosts)
        {
            httpContextAccessor.HttpContext.Session.SetString(
                    RECENT_POSTS_KEY, JsonSerializer.Serialize(recentPosts));
        }
    }
}
