﻿using Microsoft.AspNetCore.Identity;
using QAForum.Data;
using QAForum.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.Areas.Users.ViewModels
{
    public class PostDetailsViewModel
    {
        [ScaffoldColumn(false)]
        public int PostId { get; set; }
        public string Thread { get; set; }
        public string Title { get; set; }

        [Display(Name = "User Name")]
        public string UserName { get; set; }

        [Display(Name = "Post Body")]
        public string PostBody { get; set; }

        [Display(Name = "Date of Post")]
        public DateTime PostDateTime { get; set; }


        public static async Task<PostDetailsViewModel> FromPostAsync
            (Post post, UserManager<ApplicationUser> userManager)
        {
            var user = await userManager.FindByNameAsync(post.UserName);
            var name = (user?.FirstName != null || user?.LastName != null)
                        ? user.FirstName + " " + user.LastName
                        : post.UserName;

            return new PostDetailsViewModel
            {
                PostId = post.PostId,
                Thread = post.Thread.Title,
                Title = post.Title,
                UserName = name,
                PostBody = post.PostBody,
                PostDateTime = post.PostDateTime
            };
        }
    }
}
