﻿using Microsoft.AspNetCore.Identity;
using QAForum.Data;
using QAForum.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace QAForum.Areas.Users.ViewModels
{
    public class PostViewModel
    {
        [ScaffoldColumn(false)]
        public int PostId { get; set; }

        [UIHint("ShortenedString")]
        public string Thread { get; set; }
        public string Title { get; set; }

        [Display(Name = "User Name")]
        public string UserName { get; set; }

        [Display(Name = "Date of Post")]
        public DateTime PostDateTime { get; set; }

        public static IEnumerable<PostViewModel> FromPosts
                    (IEnumerable<Post> posts, UserManager<ApplicationUser> userManager)
        {
            return from post in posts
                   join user in userManager.Users
                   on userManager.NormalizeName(post.UserName)
                                              equals user.NormalizedUserName
                                              into postsUsers
                   from userOrNull in postsUsers.DefaultIfEmpty()
                   let firstName = userOrNull?.FirstName
                   let lastName = userOrNull?.LastName
                   let name = (firstName != null || lastName != null)
                              ? firstName + " " + lastName
                              : post.UserName
                   select new PostViewModel
                   {
                       PostId = post.PostId,
                       Thread = post.Thread.Title,
                       Title = post.Title,
                       UserName = name
                   };
        }

    }
}
