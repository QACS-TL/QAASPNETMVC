using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using QAForum.EF;

namespace QAForum.Areas.Admin.Pages
{
    public class DeleteUserPostsModel : PageModel
    {
        private readonly ForumDbContext context;

        [BindProperty]
        [Required]
        [Display(Name = "User Name")]
        public string UserName { get; set; }

        public string ErrorText { get; set; }
        public string Message { get; set; }

        public DeleteUserPostsModel(ForumDbContext context)
        {
            this.context = context;
        }

        public void OnGet()
        {
        }

        public void OnPost()
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var postsToDelete = context.Posts.Where(p => p.UserName == UserName);
                    var count = postsToDelete.Count();

                    context.RemoveRange(postsToDelete);
                    context.SaveChanges();

                    Message = $"{count} posts deleted";
                }
            }
            catch
            {
                ErrorText = "Sorry, something went wrong";
            }
        }
    }
}
