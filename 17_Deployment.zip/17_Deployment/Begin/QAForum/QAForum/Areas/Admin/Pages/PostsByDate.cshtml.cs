using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using QAForum.EF;
using QAForum.Models;

namespace QAForum.Areas.Admin.Pages
{
    public class PostsByDateModel : PageModel
    {
        public class StartEndDate : IValidatableObject
        {
            [Display(Name = "Start Date")]
            public DateTime? StartDate { get; set; }

            [Display(Name = "End Date")]
            public DateTime? EndDate { get; set; }

            public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
            {
                if (StartDate > EndDate)
                {
                    yield return new ValidationResult("Start date must not be after end date");
                }
            }
        }

        private readonly ForumDbContext context;

        public int PostCount { get; set; }
        public string Description { get; set; }

        [BindProperty(SupportsGet = true)]
        public StartEndDate Dates { get; set; }

        public PostsByDateModel(ForumDbContext context)
        {
            this.context = context;
        }

        public void OnGet()
        {
            Description = GetDescription();
            PostCount = GetPostCount();
        }

        private string GetDescription()
        {
            switch (Dates.StartDate, Dates.EndDate)
            {
                case (null, null):
                    return "Number of posts from all time";
                case (_, null):
                    return "Number of posts from " +
                               Dates.StartDate.Value.ToShortDateString();
                case (null, _):
                    return "Number of posts up until " +
                               Dates.EndDate.Value.ToShortDateString();
                default:
                    return $"Number of posts between" +
                        $" {Dates.StartDate.Value.ToShortDateString()}" +
                        $" and {Dates.EndDate.Value.ToShortDateString()}";
            }
        }

        private int GetPostCount()
        {
            IQueryable<Post> posts = context.Posts;
            if (Dates.StartDate != null)
            {
                posts = posts.Where(p => p.PostDateTime >= Dates.StartDate);
            }
            if (Dates.EndDate != null)
            {
                // Add one day to the date to take into account that the
                // post date time may include a "time" element. We need
                // to include times up to (but not including) midnight on
                // the following day
                posts = posts.Where(p => p.PostDateTime < Dates.EndDate.Value.AddDays(1));
            }

            return posts.Count();
        }
    }
}
