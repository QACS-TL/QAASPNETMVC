﻿using System.ComponentModel.DataAnnotations;

namespace QAForum.ViewModels
{
    public class UserSettingsViewModel
    {
        [Display(Name = "Dark Mode")]
        public bool DarkMode { get; set; }

    }
}
